print('Hello from Flask app!')
