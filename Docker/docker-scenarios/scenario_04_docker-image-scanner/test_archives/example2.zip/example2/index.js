console.log('Hello from Node.js!')
